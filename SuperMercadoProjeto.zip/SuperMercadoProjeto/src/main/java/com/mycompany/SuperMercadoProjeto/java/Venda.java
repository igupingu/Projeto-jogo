package com.mycompany.SuperMercadoProjeto.java;

class Venda {

    public void processarItem(Produto p, int quantidade) {
        float total = quantidade * p.getPreco();

        System.out.println("Produto: " + p.getNome());
        System.out.println("Quantidade: " + quantidade);
        System.out.println("Total: " + total);

        // POLIMORFISMO acontecendo aqui
        p.vender(quantidade);

        System.out.println("----------------------");
    }
}