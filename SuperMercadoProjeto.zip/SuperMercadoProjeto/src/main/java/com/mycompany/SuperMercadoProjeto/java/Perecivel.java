package com.mycompany.SuperMercadoProjeto.java;

class Perecivel extends Produto {
    private String dataValidade;

    public Perecivel(String nome, float preco, int estoque, String data) {
        super(nome, preco, estoque);
        this.dataValidade = data;
    }

    @Override
    public void vender(int qtd) {
        System.out.println("Verificando validade...");
        super.vender(qtd);
    }
}