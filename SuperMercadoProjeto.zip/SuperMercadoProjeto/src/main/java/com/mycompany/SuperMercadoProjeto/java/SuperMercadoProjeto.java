package com.mycompany.SuperMercadoProjeto.java;

public class SuperMercadoProjeto{
    public static void main(String[] args) {

        Produto p1 = new Produto("Arroz", 25.50f, 10);
        Perecivel leite = new Perecivel("Leite", 5.0f, 10, "10/05/2026");
        ProdutoImportado vinho = new ProdutoImportado("Vinho", 50.0f, 5, 0.2f);

        Venda venda = new Venda();

        venda.processarItem(p1, 2);
        venda.processarItem(leite, 3);
        venda.processarItem(vinho, 1);
    }
}