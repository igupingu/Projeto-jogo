package com.mycompany.SuperMercadoProjeto.java;

class ProdutoImportado extends Produto {
    private float taxaImportacao;

    public ProdutoImportado(String nome, float preco, int estoque, float taxa) {
        super(nome, preco, estoque);
        this.taxaImportacao = taxa;
    }

    @Override
    public void vender(int qtd) {
        float precoFinal = getPreco() + (getPreco() * taxaImportacao);
        System.out.println("Preço com taxa: " + precoFinal);
        super.vender(qtd);
    }
}