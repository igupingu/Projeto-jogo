package com.mycompany.SuperMercadoProjeto.java;

class Produto {
    private String nome;
    private float preco;
    private int estoque;

    public Produto(String nome, float preco, int estoque) {
        this.nome = nome;
        setPreco(preco);
        setEstoque(estoque);
    }

    // GETTERS
    public String getNome() {
        return nome;
    }

    public float getPreco() {
        return preco;
    }

    public int getEstoque() {
        return estoque;
    }

    // SETTERS COM VALIDAÇÃO
    public void setPreco(float preco) {
        if (preco < 0) {
            System.out.println("Erro: preço não pode ser negativo!");
        } else {
            this.preco = preco;
        }
    }

    public void setEstoque(int estoque) {
        if (estoque < 0) {
            System.out.println("Erro: estoque não pode ser negativo!");
        } else {
            this.estoque = estoque;
        }
    }

    public void adicionarEstoque(int qtd) {
        estoque += qtd;
    }

    public void vender(int qtd) {
        if (qtd <= estoque) {
            estoque -= qtd;
            System.out.println("Vendido: " + qtd + " unidades.");
        } else {
            System.out.println("Estoque insuficiente.");
        }
    }
}